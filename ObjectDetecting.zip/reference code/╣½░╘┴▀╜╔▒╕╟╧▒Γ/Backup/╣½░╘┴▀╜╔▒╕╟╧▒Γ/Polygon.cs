﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace 무게중심구하기
{
    class Polygon
    {
        Point[] p_points;

        public Polygon(Point[] pointsofPolygon)
        {
            p_points = pointsofPolygon;
        }

        public Point getMidpoint(Point x1, Point x2) //두 점사이의 중점을 구하는 메서드
        {
            return new Point((x1.X + x2.X) / 2, (x1.Y + x2.Y) / 2);
        }

        public Point getNdivedPoint(Point x1, Point x2, int i) //두 점의 벡터를 구해서 그 벡터의 1/n 지점을 구하는 메서드 
        {                                                                     
            Point vector = new Point(x2.X - x1.X, x2.Y - x1.Y);
            return new Point(x1.X + (int)(vector.X / i), x1.Y + (int)(vector.Y / i));
        }

        public Point[] returnMidpointofPolygon()
        {
            //Point temp;
            Point[] temp = new Point[p_points.Length-1];
            int i = 2;

            temp[0] = getMidpoint(p_points[0], p_points[1]); //첨엔 1/2

            while (i < p_points.Length) //중점을 찾아가는 과정에서의 좌표값들을 얻기
            {
                temp[i - 1] = getNdivedPoint(temp[i-2], p_points[i], ++i); //담엔 1/n
            }
            return temp;
        }
    }
}
