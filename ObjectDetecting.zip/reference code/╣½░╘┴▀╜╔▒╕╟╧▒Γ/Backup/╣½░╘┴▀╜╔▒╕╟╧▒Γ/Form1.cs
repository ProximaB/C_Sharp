﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 무게중심구하기
{
    public partial class Form1 : Form
    {
        public const int maxnumofVertex = 5; //꼭지점 최대 갯수 설정
        public Point[] pointsofPolygon; //도형의 꼭지점 좌표 저장
        public int numCount = 0;        //마우스 클릭 횟수

        public Form1()
        {
            InitializeComponent();
            pointsofPolygon = new Point[maxnumofVertex]; //도형의 Vertex가 저장될 장소
        }
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            //도형을 다 그리고, 중점을 구했을때 한번 더 클릭하면 초기화 시킴
            if (numCount == maxnumofVertex) 
            {
                numCount = 0;
                this.Refresh();
            }
            Graphics g = CreateGraphics();
            SolidBrush sBrush = new SolidBrush(Color.Plum);
            Pen pen = new Pen(sBrush, 3);

            //마우스 왼쪽버튼을 클릭했을때, 
            if (e.Button == MouseButtons.Left && numCount <= maxnumofVertex)
            {
                //마우스 좌표저장
                pointsofPolygon[numCount % pointsofPolygon.Length] = e.Location;
                numCount++;
            }
            if (numCount > 1)
            {
                for (int i = 0; i < numCount - 1; i++)
                    g.DrawLine(pen, pointsofPolygon[i], pointsofPolygon[(i+1) % pointsofPolygon.Length]);
            }
            
            if (numCount == maxnumofVertex)
            {
                g.DrawPolygon(pen, pointsofPolygon);
                Polygon p = new Polygon(pointsofPolygon); //Polygon클래스의 인스턴스 p 초기화

                pen.Color = Color.Red;                
                g.DrawLines(pen, p.returnMidpointofPolygon());//중점을 찾는 과정을 그려줌

                sBrush.Color = Color.Black; //중점부분에 문자 P 그리기
                g.DrawString("P", new Font("굴림", 10), sBrush, p.returnMidpointofPolygon()[p.returnMidpointofPolygon().Length-1]);
            }
            //리소스 해제
            sBrush.Dispose();
            pen.Dispose();
            g.Dispose();
        }
    }
}
