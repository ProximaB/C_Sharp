﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using AForge;
using AForge.Video;
using AForge.Video.DirectShow;
using AForge.Imaging.Filters;
using AForge.Imaging;
using AForge.Math.Geometry;

namespace BlobDetection
{
    public partial class Form1 : Form
    {
        FilterInfoCollection _fInfoCollection;
        VideoCaptureDevice _vCaptureDevice;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                _fInfoCollection = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                foreach (FilterInfo _fcategory in _fInfoCollection)
                {
                    comboBox1.Items.Add(_fcategory.Name);
                }
                comboBox1.SelectedIndex = 0;
            }
            catch (Exception _exception)
            {
                MessageBox.Show("Sorry something went wroung"+_exception);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (button2.Text == "Start")
                {
                    _vCaptureDevice = new VideoCaptureDevice(_fInfoCollection[comboBox1.SelectedIndex].MonikerString);
                    _vCaptureDevice.NewFrame += new NewFrameEventHandler(get_Frame);
                    //Start the Capture Device
                    _vCaptureDevice.Start();
                    button2.Text = "Stop";
                }
                else
                {
                    button2.Text = "Start";
                    _vCaptureDevice.Stop();
                }
            }
            catch (Exception _exception)
            {
                MessageBox.Show("No video capture device found");
            }
        }

        private void get_Frame(object sender, NewFrameEventArgs eventArgs)
        {
            //Insert image into Picuture Box
            Bitmap _BsourceFrame = (Bitmap)eventArgs.Frame.Clone();
            pictureBox1.Image = BlobDetection(_BsourceFrame);
        }

        //Blob Detection
        private Bitmap BlobDetection(Bitmap _bitmapSourceImage)
        {
            Grayscale _grayscale = new Grayscale(0.2125, 0.7154, 0.0721);
            Bitmap _bitmapGreyImage = _grayscale.Apply(_bitmapSourceImage);

            //create a edge detector instance
            DifferenceEdgeDetector _differeceEdgeDetector = new DifferenceEdgeDetector();
            Bitmap _bitmapEdgeImage = _differeceEdgeDetector.Apply(_bitmapGreyImage);

            Threshold _threshold = new Threshold(40);
            Bitmap _bitmapBinaryImage = _threshold.Apply(_bitmapEdgeImage);

            //Create a instance of blob counter algorithm
            BlobCounter _blobCounter = new BlobCounter();
            //Configure Filter
            _blobCounter.MinWidth = 70;
            _blobCounter.MinHeight = 70;
            _blobCounter.FilterBlobs = true;
            
            _blobCounter.ProcessImage(_bitmapBinaryImage);
            Blob[] _blobPoints = _blobCounter.GetObjectsInformation();

            Graphics _g = Graphics.FromImage(_bitmapSourceImage);
   
            SimpleShapeChecker _shapeChecker = new SimpleShapeChecker();
            for (int i = 0; i < _blobPoints.Length; i++)
            {
                List<IntPoint> _edgePoint = _blobCounter.GetBlobsEdgePoints(_blobPoints[i]);
                List<IntPoint> _corners = null;
                AForge.Point _center;
                float _radius;
                if (_shapeChecker.IsQuadrilateral(_edgePoint, out _corners))
                {
                    //MessageBox.Show(""+_shapeChecker.CheckShapeType(_edgePoint));
                    System.Drawing.Font _font = new System.Drawing.Font("Segoe UI", 16);
                    System.Drawing.SolidBrush _brush = new System.Drawing.SolidBrush(System.Drawing.Color.PaleGreen);
                    System.Drawing.Point[] _coordinates = ToPointsArray(_corners);
                    if (_coordinates.Length == 4)
                    {
                        int _x = _coordinates[0].X;
                        int _y = _coordinates[0].Y;
                        Pen _pen = new Pen(Color.Brown);
                        string _shapeString =""+ _shapeChecker.CheckShapeType(_edgePoint);
                        _g.DrawString(_shapeString, _font, _brush, _x, _y);
                        _g.DrawPolygon(_pen, ToPointsArray(_corners));
                    }                  
                }
                if (_shapeChecker.IsCircle(_edgePoint, out _center, out _radius))
                {
                    string _shapeString = "" + _shapeChecker.CheckShapeType(_edgePoint);
                    System.Drawing.Font _font = new System.Drawing.Font("Segoe UI", 16);
                    System.Drawing.SolidBrush _brush = new System.Drawing.SolidBrush(System.Drawing.Color.Chocolate);
                    Pen _pen = new Pen(Color.GreenYellow);
                    int x =(int)_center.X;
                    int y =(int)_center.Y;
                    _g.DrawString(_shapeString, _font, _brush, x, y);
                    _g.DrawEllipse(_pen, (float)(_center.X - _radius), 
                                         (float)(_center.Y - _radius), 
                                         (float)(_radius * 2), 
                                         (float)(_radius * 2));
                }
                if(_shapeChecker.IsTriangle(_edgePoint,out _corners))
                {
                    string _shapeString = "" + _shapeChecker.CheckShapeType(_edgePoint);
                    System.Drawing.Font _font = new System.Drawing.Font("Segoe UI", 16);
                    System.Drawing.SolidBrush _brush = new System.Drawing.SolidBrush(System.Drawing.Color.Brown);
                    Pen _pen = new Pen(Color.GreenYellow);
                    int x = (int)_center.X;
                    int y = (int)_center.Y;
                    _g.DrawString(_shapeString, _font, _brush, x, y);
                    _g.DrawPolygon(_pen,ToPointsArray(_corners));
                }               
            }
            return _bitmapSourceImage;
        }

        private System.Drawing.Point[] ToPointsArray(List<IntPoint> points)
        {
            System.Drawing.Point[] array = new System.Drawing.Point[points.Count];

            for (int i = 0, n = points.Count; i < n; i++)
            {
                array[i] = new System.Drawing.Point(points[i].X, points[i].Y);
            }

            return array;
        }
    }
}
